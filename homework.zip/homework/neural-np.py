import numpy as np
import struct
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

train_images_idx3_ubyte_file = 'train-images.idx3-ubyte'
train_labels_idx1_ubyte_file = 'train-labels.idx1-ubyte'

test_images_idx3_ubyte_file = 't10k-images.idx3-ubyte'
test_labels_idx1_ubyte_file = 't10k-labels.idx1-ubyte'

#将二进制图片转化成numpy需要的数据形式
def decode_idx3_ubyte(idx3_ubyte_file):
    bin_data = open(idx3_ubyte_file, 'rb').read()

    offset = 0
    fmt_header = '>IIII'
    magic_number, num_images, num_rows, num_cols = struct.unpack_from(fmt_header, bin_data, offset)
    print("magic:%d, count: %d, size: %d*%d" % (magic_number, num_images, num_rows, num_cols))

    image_size = num_rows * num_cols
    offset += struct.calcsize(fmt_header)
    fmt_image = '>' + str(image_size) + 'B'
    images = np.empty((num_images, num_rows, num_cols))
    for i in range(num_images):
        if (i + 1) % 10000 == 0:
            print("done %d" % (i + 1) + "pictures")
        images[i] = np.array(struct.unpack_from(fmt_image, bin_data, offset)).reshape((num_rows, num_cols))
        offset += struct.calcsize(fmt_image)
    return images

#将标签转化成numpy需要的数据形式
def decode_idx1_ubyte(idx1_ubyte_file):
    bin_data = open(idx1_ubyte_file, 'rb').read()

    offset = 0
    fmt_header = '>ii'
    magic_number, num_images = struct.unpack_from(fmt_header, bin_data, offset)
    print("magic:%d, num_images: %d zhang" % (magic_number, num_images))

    offset += struct.calcsize(fmt_header)
    fmt_image = '>B'
    labels = np.empty(num_images)
    for i in range(num_images):
        if (i + 1) % 10000 == 0:
            print("done %d" % (i + 1) + "zhang")
        labels[i] = struct.unpack_from(fmt_image, bin_data, offset)[0]
        offset += struct.calcsize(fmt_image)
    return labels

#载入数据
def load_train_images(idx_ubyte_file=train_images_idx3_ubyte_file):
    return decode_idx3_ubyte(idx_ubyte_file)


def load_train_labels(idx_ubyte_file=train_labels_idx1_ubyte_file):
    return decode_idx1_ubyte(idx_ubyte_file)


def load_test_images(idx_ubyte_file=test_images_idx3_ubyte_file):
    return decode_idx3_ubyte(idx_ubyte_file)


def load_test_labels(idx_ubyte_file=test_labels_idx1_ubyte_file):
    return decode_idx1_ubyte(idx_ubyte_file)

#正则化向量（归一化）
def normalize_data(ima):
    a_max = np.max(ima)
    a_min = np.min(ima)
    for j in range(ima.shape[0]):
        ima[j] = (ima[j] - a_min) / (a_max - a_min)
    return ima

#参数初始化,n_h为第一层神经元个数
def initialize_with_zeros(n_x, n_h, n_y):
    np.random.seed(2)
    # W1=np.random.randn(n_h,n_x)*0.00000001    # W1=np.random.randn(n_h,n_x)
    W1 = np.random.uniform(-np.sqrt(6) / np.sqrt(n_x + n_h), np.sqrt(6) / np.sqrt(n_h + n_x), size=(n_h, n_x))
    # W1=np.reshape(32,784)
    b1 = np.zeros((n_h, 1))
    # W2=np.random.randn(n_y,n_h)*0.00000001  # W2=np.random.randn(n_y,n_h)
    W2 = np.random.uniform(-np.sqrt(6) / np.sqrt(n_y + n_h), np.sqrt(6) / np.sqrt(n_y + n_h), size=(n_y, n_h))
    b2 = np.zeros((n_y, 1))

    assert (W1.shape == (n_h, n_x))
    assert (b1.shape == (n_h, 1))
    assert (W2.shape == (n_y, n_h))
    assert (b2.shape == (n_y, 1))

    parameters = {"W1": W1,
                  "b1": b1,
                  "W2": W2,
                  "b2": b2}

    return parameters

#前向传播和损失函数的计算
def forward_propagation(X, parameters):
    W1 = parameters["W1"]
    b1 = parameters["b1"]
    W2 = parameters["W2"]
    b2 = parameters["b2"]
    # print W1,X,b1
    Z1 = np.dot(W1, X) + b1
    A1 = sigmoid(Z1)
    #A1 = np.tanh(Z1)
    Z2 = np.dot(W2, A1) + b2
    A2 = sigmoid(Z2)
    cache = {"Z1": Z1,
             "A1": A1,
             "Z2": Z2,
             "A2": A2}
    return A2, cache


#loss函数
def costloss(A2, Y, parameters,t):
    W1 = parameters["W1"]
    W2 = parameters["W2"]
    L2_regulation = np.sum(np.dot(W1,W1.T)) + np.sum(np.dot(W2,W2.T))
    cost = np.dot((A2-Y).T,(A2-Y)) + t*L2_regulation
    temp_cost = np.dot((A2-Y).T,(A2-Y))
    # t = 0.00000000001
    # logprobs = np.multiply(np.log(A2 + t), Y) + np.multiply(np.log(1 - A2 + t), (1 - Y))
    # cost = np.sum(logprobs, axis=0, keepdims=True) / A2.shape[0]
    return cost,temp_cost


#反向传播和更新参数
def back_propagation(parameters, cache, X, Y,t):
    W1 = parameters["W1"]
    W2 = parameters["W2"]
    A1 = cache["A1"]
    A2 = cache["A2"]
    Z1 = cache["Z1"]
    Z2 = cache["Z2"]

    temp = 2*(A2-Y)*A2*(1-A2)
    dW2 = np.dot(temp,A1.reshape(1,np.size(A1))) + 2*t*W2
    db2 =temp

    temp2 = np.zeros_like(W2)
    for i in range(np.size(temp)):
        temp2[i] = W2[i] * temp[i]
    temp3 = A2*(1-A2)
    temp4 = np.dot(temp3, X.T)
    dW1 = np.dot(temp2.T,temp4) + 2*t*W1
    db1 = np.dot(temp2.T,temp3)

    grads = {"dW1": dW1,
             "db1": db1,
             "dW2": dW2,
             "db2": db2}

    return grads


def update_para(parameters, grads, learning_rate):
    W1 = parameters["W1"]
    b1 = parameters["b1"]
    W2 = parameters["W2"]
    b2 = parameters["b2"]
    dW1 = grads["dW1"]
    db1 = grads["db1"]
    dW2 = grads["dW2"]
    db2 = grads["db2"]

    W1 = W1 - learning_rate * dW1
    b1 = b1 - learning_rate * db1
    W2 = W2 - learning_rate * dW2
    b2 = b2 - learning_rate * db2

    parameters = {"W1": W1,
                  "b1": b1,
                  "W2": W2,
                  "b2": b2}
    return parameters

#定义sigmoid激活函数，softmax等参数。
def sigmoid(x):
    s=1/(1+np.exp(-x))
    return s

def softmax(x):
    v=np.argmax(x)
    return v

#将输入从28*28的图片变成一个列向量
def image2vector(image):
    v=np.reshape(image,[784,1])
    return v


if __name__ == '__main__':
    train_images = load_train_images()
    train_labels = load_train_labels()
    test_images = load_test_images()
    test_labels = load_test_labels()

    t = 0.001 #L2正则化强度
    lr_base = 0.015 #学习率初始化基数
    ii = 0
    n_x = 28 * 28
    n_h = 32  #隐藏层神经元个数
    n_y = 10
    parameters = initialize_with_zeros(n_x, n_h, n_y)
    loss = []
    real_loss = []
    num_train = []
    lr_record = []
    num_epoch = 40000
    for i in range(num_epoch):
        img_train = train_images[i]
        label_train1 = train_labels[i]
        label_train = np.zeros((10, 1))

        #学习率下降策略
        lr = lr_base * (1-i/num_epoch)
        lr_record.append(lr)

        label_train[int(train_labels[i])] = 1
        # print("train_label is: ", label_train)
        imgvector1 = image2vector(img_train)
        # print("imgvector1: before transform: ",imgvector1)
        imgvector = normalize_data(imgvector1)
        # print("after transform: ",imgvector)

        # imgvector=image2vector(train_images)
        A2, cache = forward_propagation(imgvector, parameters)
        # print("A2:",A2)
        pre_label = softmax(A2)
        costl,real_cost = costloss(A2, label_train, parameters,t)
        if real_cost < 0.05 and i >= 2000 and costl < 2:
            print("cost after iteration %i:" % (i))
            print(costl,real_cost)
            break
        grads = back_propagation(parameters, cache, imgvector, label_train,t)
        parameters = update_para(parameters, grads, learning_rate=lr)
        grads["dW1"] = 0
        grads["dW2"] = 0
        grads["db1"] = 0
        grads["db2"] = 0
        # if i%1000==0:
        # pass
        loss.append(costl[0][0])
        real_loss.append(real_cost[0][0])
        num_train.append(i)
        print("cost after iteration %i:" % (i))
        print(costl,real_cost)

    plt.figure(1)
    plt.plot(num_train, loss, label="loss曲线")
    plt.xlabel("num_train")
    plt.ylabel("cost_record")
    plt.ylim(0, 3)
    plt.legend()
    plt.show()

    # plt.figure(2)
    # plt.plot(num_train, real_loss, label="loss曲线")
    # plt.xlabel("num_train")
    # plt.ylabel("real_cost_record")
    # plt.ylim(0, 3)
    # plt.legend()
    # plt.show()

    for i in range(10000):
        img_train = test_images[i]
        vector_image = normalize_data(image2vector(img_train))
        label_trainx = test_labels[i]
        aa2, xxx = forward_propagation(vector_image, parameters)
        predict_value = softmax(aa2)
        if predict_value == int(label_trainx):
            ii = ii + 1
        # print("the real value is: ",label_trainx)
        # print("the value of our prediction is: ",predict_value)
    print('accuracy = ',ii/10000)

    W1 = parameters["W1"]
    b1 = parameters["b1"]
    W2 = parameters["W2"]
    b2 = parameters["b2"]
    df_W1 = pd.DataFrame(W1)
    df_W2 = pd.DataFrame(W2)
    df_b1 = pd.DataFrame(b1)
    df_b2 = pd.DataFrame(b2)
    sns.heatmap(df_W1)
    sns.heatmap(df_W2)
    sns.heatmap(df_b1)
    sns.heatmap(df_b2)
    sns.heatmap(df_b1,)
